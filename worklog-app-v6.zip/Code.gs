/****************************************************
 * 工作進度追蹤 To-Do App — 後端 v5（Google Apps Script）
 * 資料表欄位（第一個工作表，13 欄）：
 *   ID｜建立時間｜更新時間｜任務名稱｜分類｜優先度｜截止日｜狀態｜進度｜備註｜子任務｜執行日期｜重複
 * 另有兩個分頁（第一次執行時自動建立）：
 *   「分類」：分類名稱清單（預設：工作、日常）
 *   「範本」：範本ID｜範本名稱｜內容JSON
 *
 * 【使用前設定】
 * 1. APP_TOKEN：改成你自己的通行碼（前端登入畫面輸入的要跟這裡一致）
 * 2. AI 功能：左側「專案設定」→「指令碼屬性」新增 GEMINI_API_KEY
 *    （金鑰到 https://aistudio.google.com/apikey 免費申請）
 * 3. 信件功能：MAIL_TO 改成你要收提醒信的信箱
 * 4. 執行一次 setupTriggers()，授權後會自動建立三個排程：
 *    週一 07:00 寄本週到期摘要、每天 07:00 寄今日執行提醒、週日 22:00 自動備份
 * 5. 改完程式碼務必「部署 → 管理部署作業 → 編輯 → 新版本」重新部署，
 *    網址不變但程式才會生效（新增部署會產生新網址，要避免）
 ****************************************************/
var APP_TOKEN = "chuchu0720";
var MAIL_TO = "a101w6@chimei.org.tw";  // 收提醒信的信箱，留空則寄給指令碼擁有者自己
var TZ = "Asia/Taipei";
// 【務必填寫】試算表 ID：打開你的 Google 試算表，網址中 /d/ 和 /edit 之間那一長串
// 例：https://docs.google.com/spreadsheets/d/【這一段就是ID】/edit
var SPREADSHEET_ID = "1Q92YNLoWQ0ZkYxvHyyWILA8v_XSt7DrxGTJLaZMGihg";

function ss_() {
  if (SPREADSHEET_ID && SPREADSHEET_ID.indexOf("請貼上") === -1) {
    return SpreadsheetApp.openById(SPREADSHEET_ID);
  }
  var a = SpreadsheetApp.getActiveSpreadsheet(); // 綁定式專案仍可直接使用
  if (!a) throw new Error("找不到試算表：請在 Code.gs 開頭填寫 SPREADSHEET_ID");
  return a;
}

var HEADERS = ["ID","建立時間","更新時間","任務名稱","分類","優先度","截止日","狀態","進度","備註","子任務","執行日期","重複","完成時間","置頂"];

/* ============ 共用 ============ */
function getSheet_() {
  var ss = ss_();
  var sh = ss.getSheets()[0];
  if (sh.getLastRow() === 0) sh.appendRow(HEADERS);
  // 舊版升級：自動補齊新欄位標題
  var lastCol = sh.getLastColumn();
  if (lastCol < HEADERS.length) {
    sh.getRange(1, lastCol + 1, 1, HEADERS.length - lastCol)
      .setValues([HEADERS.slice(lastCol)]);
  }
  return sh;
}
function getCatSheet_() {
  var ss = ss_();
  var sh = ss.getSheetByName("分類");
  if (!sh) {
    sh = ss.insertSheet("分類");
    sh.appendRow(["分類名稱"]);
    sh.appendRow(["工作"]);
    sh.appendRow(["日常"]);
  } else if (sh.getLastRow() === 0) {
    sh.appendRow(["分類名稱"]);
  }
  return sh;
}
function getTmplSheet_() {
  var ss = ss_();
  var sh = ss.getSheetByName("範本");
  if (!sh) {
    sh = ss.insertSheet("範本");
    sh.appendRow(["範本ID","範本名稱","內容JSON"]);
  } else if (sh.getLastRow() === 0) {
    sh.appendRow(["範本ID","範本名稱","內容JSON"]);
  }
  return sh;
}
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
function jsonp_(obj, cb) {
  return ContentService.createTextOutput(cb + "(" + JSON.stringify(obj) + ")")
    .setMimeType(ContentService.MimeType.JAVASCRIPT);
}
function fmtDate_(v) {
  if (v === "" || v == null) return "";
  if (Object.prototype.toString.call(v) === "[object Date]") {
    return Utilities.formatDate(v, TZ, "yyyy-MM-dd");
  }
  return String(v);
}
function parseSubs_(v) {
  if (v === "" || v == null) return [];
  try {
    var arr = JSON.parse(String(v));
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}
function readTasks_() {
  var sh = getSheet_();
  var last = sh.getLastRow();
  if (last < 2) return [];
  var values = sh.getRange(2, 1, last - 1, HEADERS.length).getValues();
  return values.filter(function(v){ return v[0] !== ""; }).map(function(v){
    return {
      id: String(v[0]),
      created: (v[1] instanceof Date) ? Utilities.formatDate(v[1], TZ, "yyyy/MM/dd HH:mm") : String(v[1]),
      updated: (v[2] instanceof Date) ? Utilities.formatDate(v[2], TZ, "yyyy/MM/dd HH:mm") : String(v[2]),
      name: String(v[3]),
      category: String(v[4]),
      priority: String(v[5]),
      due: fmtDate_(v[6]),
      status: String(v[7]) || "待辦",
      progress: Number(v[8]) || 0,
      note: String(v[9]),
      subs: parseSubs_(v[10]),
      exec: fmtDate_(v[11]),
      repeat: String(v[12] || ""),
      doneAt: (v[13] instanceof Date) ? Utilities.formatDate(v[13], TZ, "yyyy-MM-dd") : String(v[13] || ""),
      pinned: String(v[14] || "")
    };
  });
}
function readCats_() {
  var sh = getCatSheet_();
  var last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, 1).getValues()
    .map(function(r){ return String(r[0]).trim(); })
    .filter(function(s){ return s !== ""; });
}
function readTmpls_() {
  var sh = getTmplSheet_();
  var last = sh.getLastRow();
  if (last < 2) return [];
  return sh.getRange(2, 1, last - 1, 3).getValues()
    .filter(function(r){ return r[0] !== ""; })
    .map(function(r){
      var data = null;
      try { data = JSON.parse(String(r[2])); } catch (e) {}
      return { id: String(r[0]), name: String(r[1]), data: data };
    });
}
function findRowById_(sh, id) {
  var last = sh.getLastRow();
  if (last < 2) return -1;
  var ids = sh.getRange(2, 1, last - 1, 1).getValues();
  for (var i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === String(id)) return i + 2;
  }
  return -1;
}

/* ============ 讀取（GET / JSONP） ============ */
function doGet(e) {
  var p = (e && e.parameter) || {};
  var cb = p.callback || "";
  var out;

  if (p.token !== APP_TOKEN) {
    out = { result: "unauthorized" };
  } else if (p.action === "ai") {
    out = aiSuggest_(p.mode);
  } else {
    out = { result: "list", tasks: readTasks_(), cats: readCats_(), tmpls: readTmpls_() };
  }
  return cb ? jsonp_(out, cb) : json_(out);
}

/* ============ 寫入（POST） ============ */
function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(15000);
    var p = (e && e.parameter) || {};
    if (p.token !== APP_TOKEN) return json_({ result: "unauthorized" });

    var action = p.action || "";
    var now = new Date();

    /* ---- 分類 ---- */
    if (action === "cat_add") {
      var name = String(p.name || "").trim();
      if (!name) return json_({ result: "error", message: "缺少分類名稱" });
      if (readCats_().indexOf(name) !== -1) return json_({ result: "error", message: "分類已存在" });
      getCatSheet_().appendRow([name]);
      return json_({ result: "success" });
    }
    if (action === "cat_del") {
      var dn = String(p.name || "").trim();
      var csh = getCatSheet_();
      var lastC = csh.getLastRow();
      for (var ci = 2; ci <= lastC; ci++) {
        if (String(csh.getRange(ci, 1).getValue()).trim() === dn) {
          csh.deleteRow(ci);
          return json_({ result: "success" });
        }
      }
      return json_({ result: "error", message: "找不到該分類" });
    }
    if (action === "cat_rename") {
      var oldName = String(p.name || "").trim();
      var newName = String(p.newName || "").trim();
      if (!oldName || !newName) return json_({ result: "error", message: "缺少名稱" });
      if (readCats_().indexOf(newName) !== -1) return json_({ result: "error", message: "已有同名分類" });
      var csh2 = getCatSheet_();
      var lastC2 = csh2.getLastRow();
      var found = false;
      for (var cj = 2; cj <= lastC2; cj++) {
        if (String(csh2.getRange(cj, 1).getValue()).trim() === oldName) {
          csh2.getRange(cj, 1).setValue(newName);
          found = true;
          break;
        }
      }
      if (!found) return json_({ result: "error", message: "找不到該分類" });
      // 同步更新所有任務的分類欄（第 5 欄）
      var tsh = getSheet_();
      var lastT = tsh.getLastRow();
      if (lastT >= 2) {
        var catRange = tsh.getRange(2, 5, lastT - 1, 1);
        var catVals = catRange.getValues();
        var changed = false;
        for (var ti = 0; ti < catVals.length; ti++) {
          if (String(catVals[ti][0]).trim() === oldName) { catVals[ti][0] = newName; changed = true; }
        }
        if (changed) catRange.setValues(catVals);
      }
      return json_({ result: "success" });
    }

    /* ---- 範本 ---- */
    if (action === "tmpl_add") {
      var tn = String(p.name || "").trim();
      var td = String(p.data || "");
      if (!tn || !td) return json_({ result: "error", message: "缺少範本名稱或內容" });
      try { JSON.parse(td); } catch (err) { return json_({ result: "error", message: "範本內容格式錯誤" }); }
      getTmplSheet_().appendRow([Utilities.getUuid(), tn, td]);
      return json_({ result: "success" });
    }
    if (action === "tmpl_del") {
      var tid = String(p.id || "");
      var tsh2 = getTmplSheet_();
      var row = findRowById_(tsh2, tid);
      if (row === -1) return json_({ result: "error", message: "找不到該範本" });
      tsh2.deleteRow(row);
      return json_({ result: "success" });
    }

    /* ---- 任務 ---- */
    var id = String(p.id || "");
    if (!id) return json_({ result: "error", message: "缺少 ID" });
    var sh = getSheet_();

    if (action === "add") {
      sh.appendRow([
        id, now, now,
        p.name || "", p.category || "", p.priority || "中",
        p.due || "", p.status || "待辦", Number(p.progress) || 0, p.note || "",
        p.subs || "[]", p.exec || "", p.repeat || "",
        (p.status === "已完成") ? now : "", p.pinned || ""
      ]);
      return json_({ result: "success" });
    }

    if (action === "update") {
      var r = findRowById_(sh, id);
      if (r === -1) return json_({ result: "error", message: "找不到該任務" });
      var oldStatus = String(sh.getRange(r, 8).getValue());
      var oldDone = sh.getRange(r, 14).getValue();
      var oldPin = String(sh.getRange(r, 15).getValue() || "");
      var newStatus = p.status || "待辦";
      var doneAt = "";
      if (newStatus === "已完成") doneAt = (oldStatus === "已完成" && oldDone) ? oldDone : now;
      var pin = (p.pinned !== undefined) ? p.pinned : oldPin;
      sh.getRange(r, 3, 1, 13).setValues([[
        now,
        p.name || "", p.category || "", p.priority || "中",
        p.due || "", newStatus, Number(p.progress) || 0, p.note || "",
        p.subs || "[]", p.exec || "", p.repeat || "",
        doneAt, pin
      ]]);
      return json_({ result: "success" });
    }

    if (action === "pin") {
      var rp = findRowById_(sh, id);
      if (rp === -1) return json_({ result: "error", message: "找不到該任務" });
      sh.getRange(rp, 15).setValue(p.val === "1" ? "1" : "");
      return json_({ result: "success" });
    }

    if (action === "delete") {
      var r2 = findRowById_(sh, id);
      if (r2 === -1) return json_({ result: "error", message: "找不到該任務" });
      sh.deleteRow(r2);
      return json_({ result: "success" });
    }

    return json_({ result: "error", message: "未知動作：" + action });
  } catch (err) {
    return json_({ result: "error", message: String(err) });
  } finally {
    lock.releaseLock();
  }
}

/* ============ AI 工作建議（Gemini） ============ */
function aiSuggest_(mode) {
  var key = PropertiesService.getScriptProperties().getProperty("GEMINI_API_KEY");
  if (!key) return { result: "error", message: "尚未設定 GEMINI_API_KEY（專案設定 → 指令碼屬性）" };

  var tasks = readTasks_();
  var today = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd (EEE)");
  var lines = tasks.map(function(t){
    var s = "- [" + t.status + "] " + t.name +
            "（分類:" + (t.category || "無") + "／優先度:" + t.priority +
            "／執行日:" + (t.exec || "無") + "／截止:" + (t.due || "無") +
            "／進度:" + t.progress + "%／最後更新:" + (t.updated || "不明") +
            (t.repeat ? "／重複:" + t.repeat : "") + "）";
    if (t.subs && t.subs.length) {
      s += "\n" + t.subs.map(function(x){
        return "    ・" + (x.d ? "[完成] " : "[未完成] ") + x.t +
               (x.x ? "（執行:" + x.x + "）" : "") + (x.due ? "（截止:" + x.due + "）" : "");
      }).join("\n");
    }
    return s;
  }).join("\n");

  var common =
    "你是我的行政工作助理，任務是替我做決定，不是泛泛分析。今天是 " + today + "。\n" +
    "以下是我的任務清單（含子任務、執行日、截止日、進度、最後更新時間）：\n" + lines + "\n\n" +
    "共同規則：只挑重點講，不要每件任務都點評；引用時寫出完整任務名稱；" +
    "直接進入重點，不要問候與開場白；純文字輸出，絕對不要使用 * # - 等 Markdown 符號。\n\n";

  var prompt;
  if (mode === "review") {
    prompt = common +
      "請做一次「整體健檢」，輸出以下段落（某段沒有內容就整段省略）：\n" +
      "【卡住的案件】找出可能卡住的任務：進度長期停在同個百分比（用最後更新時間判斷，未完成且超過 7 天沒更新就算）、或已逾期超過 3 天的。每件寫：任務名稱＋卡多久＋一句處置建議（該催誰、拆小步驟、還是乾脆結案）\n" +
      "【逾期清單】所有已逾期的未完成事項（含子任務），附截止日與逾期天數，按最嚴重排前面\n" +
      "【安排過擠】未來 14 天內，哪一天的執行日或截止日擠了 3 件以上，建議把哪件挪去哪天\n" +
      "【可以收尾】進度已達 80% 以上的任務，鼓勵我今天順手收掉\n" +
      "全部沒有問題的話，就簡短誇獎我並總結目前狀態。";
  } else {
    prompt = common +
      "請以「優先建議與留意事項」的形式回覆，結構如下：\n" +
      "第一行：一句話總結目前整體狀態（例如「目前有 2 件需要立即留意」或「目前沒有需要特別留意的項目，狀況良好」），前面加一個符合狀態的 emoji（✅ 或 ⚠️）。\n" +
      "接著空一行，列出至多 3 點優先建議，依「今天的執行日 > 已逾期 > 最近截止 > 卡住超過 7 天沒更新 > 高優先度」挑選。每一點的寫法：\n" +
      "・以具體動詞開頭（例如：立即確認、今天完成、著手處理、盤點、追蹤、順手收掉），接著寫出完整任務名稱\n" +
      "・說明為什麼是它（引用具體日期、逾期天數或停滯天數）\n" +
      "・給出明確的下一步行動（有子任務的話直接點名該做哪一個子任務；卡住的話建議該催誰或怎麼拆解）\n" +
      "每點 2–3 句話，最緊急的排最前面。如果有看起來急但其實可以先放著的事（截止還遠、或在等別人），在最後補一點說明哪件可以放心先擱著、為什麼。\n" +
      "每一點用「1. 2. 3.」編號開頭，點與點之間空一行。不重要的任務不要提。";
  }

  var basePayload = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
  };
  // 依序嘗試多個模型：前面的額度用盡（429）或不存在（404）就換下一個
  var MODELS = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.0-flash"];
  var lastErr = "";
  for (var mi = 0; mi < MODELS.length; mi++) {
    var payload = JSON.parse(JSON.stringify(basePayload));
    if (MODELS[mi].indexOf("gemini-2.5") === 0) {
      // 2.5 系列：關閉內部思考，避免思考吃掉輸出字數導致回應被切斷
      payload.generationConfig.thinkingConfig = { thinkingBudget: 0 };
    }
    var res = UrlFetchApp.fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/" + MODELS[mi] + ":generateContent?key=" + key,
      { method: "post", contentType: "application/json", payload: JSON.stringify(payload), muteHttpExceptions: true }
    );
    var codeNum = res.getResponseCode();
    if (codeNum === 200) {
      try {
        var data = JSON.parse(res.getContentText());
        var text = data.candidates[0].content.parts.map(function(pp){ return pp.text || ""; }).join("");
        return { result: "ai", text: text };
      } catch (e) {
        lastErr = "AI 回應解析失敗";
        continue;
      }
    }
    lastErr = "Gemini（" + MODELS[mi] + "）回應 " + codeNum + "：" + res.getContentText().slice(0, 150);
    if (codeNum !== 429 && codeNum !== 404 && codeNum !== 503) break; // 其他錯誤不用換模型硬試
  }
  return { result: "error", message: lastErr };
}

/* ============ 每週一 07:00：本週到期摘要信 ============ */
function sendWeeklyDigest() {
  var tasks = readTasks_();
  var today = new Date();
  var t7 = new Date(today.getTime() + 7 * 86400000);
  var tdStr = Utilities.formatDate(today, TZ, "yyyy-MM-dd");
  var t7Str = Utilities.formatDate(t7, TZ, "yyyy-MM-dd");

  var items = [];
  tasks.forEach(function(t){
    if (t.status === "已完成") return;
    if (t.due && t.due <= t7Str) {
      items.push({ label: t.name, cat: t.category, due: t.due, overdue: t.due < tdStr, exec: t.exec });
    }
    (t.subs || []).forEach(function(s){
      if (!s.d && s.due && s.due <= t7Str) {
        items.push({ label: t.name + " › " + s.t, cat: t.category, due: s.due, overdue: s.due < tdStr, exec: s.x || "" });
      }
    });
  });
  if (items.length === 0) return;
  items.sort(function(a, b){ return a.due < b.due ? -1 : 1; });

  var rows = items.map(function(it){
    return '<tr>' +
      '<td style="padding:8px 12px;border-bottom:1px solid #eadcc4;">' + it.label +
        (it.cat ? ' <span style="color:#a1795a;font-size:12px;">[' + it.cat + ']</span>' : '') + '</td>' +
      '<td style="padding:8px 12px;border-bottom:1px solid #eadcc4;color:#9c8a72;">' + (it.exec || "—") + '</td>' +
      '<td style="padding:8px 12px;border-bottom:1px solid #eadcc4;font-weight:bold;color:' +
        (it.overdue ? '#c05555' : '#a8742b') + ';">' + it.due + (it.overdue ? '（已逾期）' : '') + '</td></tr>';
  }).join("");

  var html =
    '<div style="font-family:Microsoft JhengHei,sans-serif;max-width:640px;background:#fffcf5;padding:8px;">' +
    '<h2 style="color:#5b452e;">📋 本週工作到期提醒</h2>' +
    '<p style="color:#8a7561;">早安！以下是 7 天內到期（含已逾期）的工作事項：</p>' +
    '<table style="border-collapse:collapse;width:100%;background:#ffffff;border:1px solid #eadcc4;border-radius:8px;">' +
    '<tr style="background:#f6efe3;"><th style="padding:8px 12px;text-align:left;color:#5b452e;">事項</th>' +
    '<th style="padding:8px 12px;text-align:left;color:#5b452e;">執行日</th>' +
    '<th style="padding:8px 12px;text-align:left;color:#5b452e;">截止日</th></tr>' + rows + '</table>' +
    '<p style="color:#b3a288;font-size:12px;margin-top:16px;">— 工作進度追蹤 App 自動發送</p></div>';

  var to = MAIL_TO || Session.getEffectiveUser().getEmail();
  MailApp.sendEmail({ to: to, subject: "【本週工作提醒】" + items.length + " 項工作將於 7 天內到期", htmlBody: html });
}

/* ============ 每天 07:00：今日執行提醒信（無事項則不寄） ============ */
function sendDailyDigest() {
  var tasks = readTasks_();
  var tdStr = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd");

  var execItems = [], dueItems = [];
  tasks.forEach(function(t){
    if (t.status === "已完成") return;
    if (t.exec === tdStr) execItems.push({ label: t.name, cat: t.category });
    (t.subs || []).forEach(function(s){
      if (!s.d && s.x === tdStr) execItems.push({ label: t.name + " › " + s.t, cat: t.category });
    });
    if (t.due === tdStr) dueItems.push({ label: t.name, cat: t.category });
    (t.subs || []).forEach(function(s){
      if (!s.d && s.due === tdStr) dueItems.push({ label: t.name + " › " + s.t, cat: t.category });
    });
  });
  if (execItems.length === 0 && dueItems.length === 0) return; // 今天沒事就不打擾

  function ul(items) {
    return '<ul style="margin:6px 0 14px;padding-left:20px;color:#574432;">' +
      items.map(function(it){
        return '<li style="margin:4px 0;">' + it.label +
          (it.cat ? ' <span style="color:#a1795a;font-size:12px;">[' + it.cat + ']</span>' : '') + '</li>';
      }).join("") + '</ul>';
  }

  var html =
    '<div style="font-family:Microsoft JhengHei,sans-serif;max-width:640px;background:#fffcf5;padding:8px;">' +
    '<h2 style="color:#5b452e;">☀️ 今日工作提醒（' + tdStr + '）</h2>' +
    (execItems.length ? '<h3 style="color:#c8823a;margin-bottom:0;">今日執行（' + execItems.length + ' 項）</h3>' + ul(execItems) : '') +
    (dueItems.length ? '<h3 style="color:#c05555;margin-bottom:0;">今日截止（' + dueItems.length + ' 項）</h3>' + ul(dueItems) : '') +
    '<p style="color:#b3a288;font-size:12px;margin-top:16px;">— 工作進度追蹤 App 自動發送</p></div>';

  var to = MAIL_TO || Session.getEffectiveUser().getEmail();
  var subj = "【今日工作提醒】" +
    (execItems.length ? "執行 " + execItems.length + " 項" : "") +
    (execItems.length && dueItems.length ? "、" : "") +
    (dueItems.length ? "截止 " + dueItems.length + " 項" : "");
  MailApp.sendEmail({ to: to, subject: subj, htmlBody: html });
}

/* ============ 每週日 22:00：自動備份試算表 ============ */
function weeklyBackup() {
  var ss = ss_();
  var file = DriveApp.getFileById(ss.getId());
  var it = DriveApp.getFoldersByName("工作進度備份");
  var folder = it.hasNext() ? it.next() : DriveApp.createFolder("工作進度備份");
  var name = "備份_" + Utilities.formatDate(new Date(), TZ, "yyyyMMdd") + "_" + ss.getName();
  file.makeCopy(name, folder);

  // 只保留最近 8 份備份，其餘移到垃圾桶
  var files = folder.getFiles();
  var arr = [];
  while (files.hasNext()) {
    var f = files.next();
    if (f.getName().indexOf("備份_") === 0) arr.push(f);
  }
  arr.sort(function(a, b){ return b.getDateCreated() - a.getDateCreated(); });
  for (var i = 8; i < arr.length; i++) arr[i].setTrashed(true);
}

/* ============ 一次執行：建立所有排程 ============ */
function setupTriggers() {
  // 先清掉舊的同名排程，避免重複
  ScriptApp.getProjectTriggers().forEach(function(t){
    var fn = t.getHandlerFunction();
    if (fn === "sendWeeklyDigest" || fn === "sendDailyDigest" || fn === "weeklyBackup") {
      ScriptApp.deleteTrigger(t);
    }
  });
  ScriptApp.newTrigger("sendWeeklyDigest").timeBased()
    .onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(7).create();
  ScriptApp.newTrigger("sendDailyDigest").timeBased()
    .everyDays(1).atHour(7).create();
  ScriptApp.newTrigger("weeklyBackup").timeBased()
    .onWeekDay(ScriptApp.WeekDay.SUNDAY).atHour(22).create();
}
